package com.cognizant.objectified.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cognizant.objectified.model.Courses;
import com.cognizant.objectified.service.CourseService;

 
@Controller
@RequestMapping("/Course")
public class CourseController {
	
	@Autowired
	private CourseService courseService;
	
	@GetMapping("/show")
	public String ListCourses(Model theModel){		
		Courses courses = new Courses();
		theModel.addAttribute("course",courses);
		List<Courses> coursesList = courseService.getCourses();
		theModel.addAttribute("courses",coursesList);
		return "Courses";
	}
	@PostMapping("/add")
	public String addCourses(@ModelAttribute("course") Courses theCourse){		
		courseService.addCourse(theCourse);
		return "redirect:/Course/show";
	}
	
	@GetMapping("/editCourse")
	public String editCourse(@RequestParam("CourseId") int theId,
								Model theModel){
		Courses course = courseService.getCourses(theId);
		theModel.addAttribute("course", course);
		return "EditCourses";
	}

	@GetMapping("/delete")
	public String deleteCourse(@RequestParam("CourseId") int Id, Model theModel){
		courseService.deleteCourse(Id);
		return "redirect:/Course/show";

	}
}
