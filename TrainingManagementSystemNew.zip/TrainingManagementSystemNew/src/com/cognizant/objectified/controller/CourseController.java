package com.cognizant.objectified.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cognizant.objectified.dao.CourseDAO;
import com.cognizant.objectified.model.Courses;

 
@Controller
@RequestMapping("/Course")
public class CourseController {
	
	@Autowired
	private CourseDAO dao;
	
	@RequestMapping("/show")
	public String ListCourses(Model theModel){		
		List<Courses> coursesList = dao.getCourses();
		theModel.addAttribute("courses",coursesList);
		return "Courses";
	}

}
