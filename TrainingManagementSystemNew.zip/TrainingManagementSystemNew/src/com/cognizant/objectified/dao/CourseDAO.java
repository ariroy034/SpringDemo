package com.cognizant.objectified.dao;

import java.util.List;

import com.cognizant.objectified.model.Courses;

public interface CourseDAO {
	public List<Courses> getCourses();
}
