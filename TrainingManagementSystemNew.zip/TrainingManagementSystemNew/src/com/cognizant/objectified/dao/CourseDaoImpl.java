package com.cognizant.objectified.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.objectified.model.Courses;
@Repository
public class CourseDaoImpl implements CourseDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	public List<Courses> getCourses() {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Courses> theQuery = currentSession.createQuery("from Courses order by name",Courses.class);
		List<Courses> courseList = theQuery.getResultList();
		return courseList;
	}


	@Override
	public void addCourse(Courses theCourse) {
		Session currentSession = sessionFactory.getCurrentSession();
		currentSession.saveOrUpdate(theCourse);
	}


	@Override
	public Courses getCourses(int theId) {
		Session currentSession = sessionFactory.getCurrentSession();
		Courses course = currentSession.get(Courses.class,theId);
		return course;
	}


	@Override
	public void deleteCourse(int id) {
		Session currentSession = sessionFactory.getCurrentSession();
		Query query=currentSession.createQuery("delete from Courses where id=:courseId");
		query.setParameter("courseId",id);
		query.executeUpdate();
	}

}
