package com.cognizant.objectified.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.objectified.model.Courses;
@Repository
public class CourseDaoImpl implements CourseDAO{

	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Override
	@Transactional
	public List<Courses> getCourses() {
		Session currentSession = sessionFactory.getCurrentSession();
		Query<Courses> theQuery = currentSession.createQuery("from Courses",Courses.class);
		List<Courses> courseList = theQuery.getResultList();
		return courseList;
	}

}
