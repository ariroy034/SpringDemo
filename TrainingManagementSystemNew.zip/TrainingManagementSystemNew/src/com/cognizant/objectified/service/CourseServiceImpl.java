package com.cognizant.objectified.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cognizant.objectified.dao.CourseDAO;
import com.cognizant.objectified.model.Courses;
@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseDAO dao;
	
	@Transactional
	@Override
	public List<Courses> getCourses() {
		return dao.getCourses();
	}

	@Transactional
	@Override
	public void addCourse(Courses theCourse) {
		dao.addCourse(theCourse);		
	}

	@Override
	@Transactional
	public Courses getCourses(int theId) {
		return dao.getCourses(theId);
	}

	@Override
	@Transactional
	public void deleteCourse(int id) {
		dao.deleteCourse(id);
	}

}
