package com.cognizant.objectified.service;

import java.util.List;

import com.cognizant.objectified.model.Courses;

public interface CourseService {
	
	public List<Courses> getCourses();

	public void addCourse(Courses theCourse);

	public Courses getCourses(int theId);

	public void deleteCourse(int id);
	
}
